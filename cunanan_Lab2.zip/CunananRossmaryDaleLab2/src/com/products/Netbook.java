package com.products;

public class Netbook extends Laptop {

	public Netbook(String CPU, String manufacturer, String color, int price) {
		super(CPU, manufacturer, color, price);
		
		
		
	
		
	}
        
	
	 public void type() {
		 System.out.println("This is good for typing");
	 }
	 
}
