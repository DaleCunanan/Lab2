package com.products;

public class Laptop extends TechProducts{
	
	String CPU;
	String manufacturer;
	String color;
	int price;
	

	public Laptop( String CPU, String manufacturer ,
			String color, int price ) {
		this.CPU = CPU;
		this.manufacturer = manufacturer;
		this.color = color;
		this.price = price;
		
	}
	
	public void type() { 
		System.out.println("This is good for typing");
	}
	
	
}
