package com.products;

public class TechProducts {
	private String RAM;
	private String size;
	private String network;
	private String os;
	private int warranty;
	
	
	
	
	public void setRAM(String RAM ) {
		this.RAM = RAM;
	}
	
	public void setSize(String size) {
		this.size = size;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public void setOs(String os) {
		this.os = os;
	}
	
	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}
	
	public String getRAM() {
		return this.getRAM();		
	}
	public String getSize() {
		return this.getSize();
	}
	
	public String getNetwork() {
		return this.getNetwork();
	}
	
	public String getOs() {
		return this.getOs();
	}
	
	public int getWarranty() {
		return this.getWarranty();
		}
	
	public void recommend() {
		System.out.println("Here are some recommended products for you :");
	}
	
	public void specification() {
		System.out.println("RAM : " + RAM);
		System.out.println("SIZE: " + size);
		System.out.println("Network capability: " + network);
		System.out.println("OS: " + os);
		System.out.println("Both products have " + warranty + " years of warranty");
	}

	
}
