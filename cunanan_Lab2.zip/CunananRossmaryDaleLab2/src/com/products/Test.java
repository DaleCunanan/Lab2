package com.products;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		TechProducts p1 = new TechProducts();
		p1.setRAM("8 GB");
		p1.setSize("14 inches"); 
		p1.setNetwork("WIRELESS LAN");
		p1.setOs("Windows");
		p1.setWarranty(7);
		p1.recommend();
		
		Netbook NB1 = new Netbook("inter core 3", "Asus" , "Silver", 18000);{
			
		}
		

		
		
		Laptop LP1 = new Laptop ("intel core 5" , "Acer" , "Red" , 35000); {
				}
		
		
		Scanner s = new Scanner (System.in);
		System.out.println("Do you want to see their features? (Type YES)");
		String one = s.nextLine();
		
		System.out.println("OKAY!! HERE YOU GO: ");
		System.out.println();
		p1.recommend();
		
		System.out.println("--------------------------------------");
		System.out.println();
		p1.specification();
		
		System.out.println();
		System.out.println("-----------------------------------------");
		
		System.out.println("This laptop is from " + LP1.manufacturer);
		System.out.println("The CPU model of this laptop is " + LP1.CPU);
		System.out.println("The best seller  color is " + LP1.color +
				" and the price starts at " + LP1.price + " PESOS...");
		
		LP1.type();
		
		System.out.println();
		System.out.println("netbook is also AVAILABLE here.");
		
	
		System.out.println("This netbook is from " + NB1.manufacturer);
		System.out.println("The CPU model is " + NB1.CPU);
		System.out.println("The best seller color is " + NB1.color
				+ "and the fixed price is " + NB1.price);
		
		NB1.type();
		
		System.out.println();
		Scanner s1 = new Scanner(System.in);
		System.out.println("Are u satisfied with the products?");
		String two = s1.next();
		
		
		 if (two.equals("yes")) {
		        System.out.println("Thank you!");
		    } else {
		        System.out.println("Okay but please come again..");
	}
	

} 
}